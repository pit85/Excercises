
public class MorseCodeTranslatorTest {

	public static void main(String[] args) {

		MorseCodeTranslator translator = new MorseCodeTranslator();

		translator.startTranslation(translator.inputText());

	}

}
