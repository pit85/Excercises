
public class PalindromeTest {

	public static void main(String[] args) {

		Palindrome palindrome = new Palindrome();

		palindrome.start(10, 999);

	}

}
